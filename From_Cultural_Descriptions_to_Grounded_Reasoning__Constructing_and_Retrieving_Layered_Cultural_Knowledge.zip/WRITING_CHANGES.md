# What changed in this revision

This is a full-language edit of the existing end-to-end paper, not a new research design. The paper still describes both the triple-based and frame-based branches of the cultural knowledge framework. The equations, evaluation conditions, citations, figures, result tables, numerical results, and caveats were retained.

## Writing guidance applied from the supplied `Publication101: Scientific Communications` slides

- **Avoid unnecessary hedging and intensifiers** (slides 10-14). Results now state the direction, size, evaluation setting, and statistical comparisons directly. Uncertainty is retained only where needed, especially in the NormAd, held-out, and LLM-judge findings.
- **Use simple words and avoid noun clusters** (the slides' *Basic Principles* and *Clarity in Writing* sections). Dense terms were explained before being used. Technical terms necessary to the work remain: retrieval-augmented generation (RAG), knowledge graph (KG), provenance, triples, cultural layers, entity resolution, cross-cultural alignment, norm types, frames, and adaptive retrieval.
- **Present the task, gap, approach, and evidence in that order** (the slides' introduction-writing section). The Introduction is aimed at someone unfamiliar with the project. The Methodology describes the entire end-to-end system, rather than focusing only on the latest version.
- **Explain why each method is used before explaining how** (the slides' Methodology sections). Each methodological stage begins with its purpose.
- **Give precise measurements rather than generic conclusions** (the slides' Results guidance). The 92.9%, 91.4%, 78.6%, recall, coherence, NormAd, and held-out findings and their relevant limitations remain intact.
- **Keep diagrams and captions self-explanatory** (the slides' figure guidance). Figure 1 explicitly shows the parallel triple-based and frame-based KG construction paths.

## Example revision

**Before:**

> Ordinary retrieval-augmented generation (RAG) can retrieve these descriptions; whether an explicit representation of the underlying relationships provides additional value is an empirical question.

**After:**

> Retrieval-augmented generation (RAG) can find relevant descriptions and give them to a language model. However, passage retrieval does not explicitly organize how a practice relates to a social norm or an underlying value. We study whether adding this structure helps models answer culturally grounded questions.

## What remains unchanged and what still needs review

- The manuscript is still intended for a reader with no prior knowledge of the project.
- All experiment figures and numbers in the draft come from the same `kg-v3` report as the previous draft. The paper does not assert that held-out generalization has been solved.
- The reported open-ended and pathway-quality scores depend on Phi-4 automatic judgment and still require human validation.
- The August pathways remain a historical baseline affected by the original corpus construction and leakage concerns.
- The abstract and conclusion remain placeholders, as previously requested for advisor review.
- Bibliography entries and their links should receive a final author verification before submission.
- The PDF uses an unofficial ACL-like preview style; add `acl.sty` and related official ACL template assets when preparing the Overleaf submission.
