# Cultural knowledge graph paper — clearer-writing revision

This package contains the revised **full-system** ACL-style manuscript. It retains the CultureBank → text/triples/KG/frames → retrieval → LLM answering → evaluation narrative and the KG v3 results.

## Files

- `main.tex`: revised paper
- `references.bib`: existing bibliography, with the original citation keys
- `acl_preview.sty`, `preview_refs.tex`: local preview fallback (not the official ACL template)
- `WRITING_CHANGES.md`: changes and how the scientific-writing slideshow was applied

## Compile the preview

```bash
latexmk -pdf main.tex
```

For official ACL formatting, add the official `acl.sty` and related template files from https://github.com/acl-org/acl-style-files. The conditional TeX preamble will then use the official style. Use the official conference instructions when preparing the final submission.

Source-code reference: https://github.com/amir01mn/cultural-contextualization-research-cur/tree/kg-v3 (commit `2fbc1ca830bf0f2898148a3625a74e8fd51e30cf`).
